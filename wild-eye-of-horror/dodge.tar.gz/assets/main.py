import pygame
import random
import asyncio

pygame.init()
pygame.mixer.init()

ekran_genisligi = 600
ekran_yuksekligi = 400
ekran = pygame.display.set_mode((ekran_genisligi, ekran_yuksekligi))

SIYAH = (0, 0, 0)
BEYAZ = (255, 255, 255)

async def main():
    try:
        hedef_resim = pygame.image.load("eyeye.png")
        hedef_resim = pygame.transform.scale(hedef_resim, (100, 100))
    except:
        hedef_resim = None

    try:
        karakater_essam1 = pygame.image.load("karakater.png")
        karakater_essam2 = pygame.transform.scale(karakater_essam1, (100, 100))
        karakater_essam = pygame.transform.flip(karakater_essam2, True, False)
    except:
        karakater_essam = None

    try:
        oluekeran1 = pygame.image.load("oluekaran.jpg")
        oluekaran = pygame.transform.scale(oluekeran1, (ekran_genisligi, ekran_yuksekligi))
    except:
        oluekaran = None

    oyuncu_x, oyuncu_y = 250, 300
    oyuncu_hizi = 7
    can = 3
    hedef_x, hedef_y = random.randint(0, 540), 0
    dusme_hizi = 5
    skor = 0
    font = pygame.font.SysFont("timesnewroman", 36)
    saat = pygame.time.Clock()

    try:
        pygame.mixer.music.load("ses.ogg")
        pygame.mixer.music.play(-1)
        acimasesi = pygame.mixer.Sound("sesey.ogg")
    except:
        acimasesi = None

    oyun_calisiyor = True
    oldun = False  # Öldün durumunu flag olarak tutuyoruz

    while oyun_calisiyor:
        saat.tick(60)

        for olay in pygame.event.get():
            if olay.type == pygame.QUIT:
                oyun_calisiyor = False

        tuslar = pygame.key.get_pressed()

        if not oldun:
            # --- OYUN DEVAM EDİYORKEN ---
            ekran.fill(SIYAH)

            if tuslar[pygame.K_LEFT] and oyuncu_x > 0:
                oyuncu_x -= oyuncu_hizi
                if karakater_essam2:
                    karakater_essam = pygame.transform.flip(karakater_essam2, True, False)

            if tuslar[pygame.K_RIGHT] and oyuncu_x < 550:
                oyuncu_x += oyuncu_hizi
                if karakater_essam2:
                    karakater_essam = pygame.transform.flip(karakater_essam2, False, False)

            hedef_y += dusme_hizi
            oyuncu_kutu = pygame.Rect(oyuncu_x, oyuncu_y, 50, 50)
            hedef_kutu = pygame.Rect(hedef_x, hedef_y, 60, 60)

            if hedef_y > 400:
                hedef_y = 0
                hedef_x = random.randint(0, 540)
                skor += 1
                if skor % 5 == 0:
                    dusme_hizi += 1

            if oyuncu_kutu.colliderect(hedef_kutu):
                if acimasesi:
                    acimasesi.play()
                can -= 1
                hedef_y = 0
                hedef_x = random.randint(0, 540)
                if can <= 0:
                    oldun = True  # İç içe döngüye girmek yerine durumu değiştiriyoruz

            if karakater_essam:
                ekran.blit(karakater_essam, (oyuncu_x, oyuncu_y))
            if hedef_resim:
                ekran.blit(hedef_resim, (hedef_x, hedef_y))

            skor_yazisi = font.render(f"Skor: {skor}", True, BEYAZ)
            can_yazisi = font.render(f"Can: {can}", True, BEYAZ)
            ekran.blit(skor_yazisi, (10, 10))
            ekran.blit(can_yazisi, (10, 40))

        else:
            # --- OYUN BİTTİĞİNDE (ÖLÜM EKRANI) ---
            if oluekaran:
                ekran.blit(oluekaran, (0, 0))
            else:
                ekran.fill(SIYAH)

            tekrar = font.render("Tekrar oynamak icin R'ye basin", True, BEYAZ)
            ekran.blit(tekrar, (10, 10))

            if tuslar[pygame.K_r]:
                oyuncu_x, oyuncu_y = 250, 300
                can = 3
                hedef_x, hedef_y = random.randint(0, 540), 0
                dusme_hizi = 5
                skor = 0
                oldun = False

        pygame.display.update()
        
        # TEK BİR ASYNC BEKLEME - Ana döngünün sonunda
        await asyncio.sleep(0)

    pygame.quit()

asyncio.run(main())