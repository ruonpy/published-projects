import asyncio
import os
import random
import sys
import pygame


pygame.init()


WIDTH = 800
HEIGHT = 600


BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def asset(filename):
    return os.path.join(BASE_DIR, filename)


def load_image(filename, alpha=True):
    try:
        path = asset(filename)

        if alpha:
            image = pygame.image.load(path).convert_alpha()
        else:
            image = pygame.image.load(path).convert()

        return image

    except Exception as e:
        print("IMAGE ERROR:", filename, e)
        return None


def load_sound(filename):
    try:
        if not pygame.mixer.get_init():
            pygame.mixer.init()

        return pygame.mixer.Sound(asset(filename))

    except Exception as e:
        print("SOUND ERROR:", filename, e)
        return None


async def play_game():

    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Renko Pygame Ekrani")

    clock = pygame.time.Clock()

    font = pygame.font.SysFont(None, 32)
    intro_font = pygame.font.SysFont(None, 48)
    countdown_font = pygame.font.SysFont(None, 80)

    # ---------------------------------------------------------
    # COLORS
    # ---------------------------------------------------------

    colors = [
        (0, 0, 255),
        (0, 255, 255),
        (139, 69, 19),
        (128, 128, 128),
        (255, 255, 255),
        (0, 0, 128),
    ]

    intro_colors = [
        (30, 30, 60),
        (50, 0, 80),
        (20, 60, 40),
        (80, 20, 40),
        (80, 60, 0),
    ]

    color_map = {
        "KIRMIZI": (255, 0, 0),
        "TURUNCU": (255, 165, 0),
        "SARI": (255, 255, 0),
        "YESIL": (0, 255, 0),
        "PEMBE": (255, 0, 255),
        "MOR": (128, 0, 128),
    }

    # ---------------------------------------------------------
    # GAME STATE
    # ---------------------------------------------------------

    color_index = 0
    intro_color_index = 0

    in_intro = True
    game_won = False
    black_screen = False

    black_screen_start_time = None

    scream_started = False
    scream_finished = False

    pilis_started = False
    pilis_finished = False

    malsef_started = False
    malsef_finished = False

    room_scene = False
    room_scene_start_time = None

    room_player_moving_left = False
    room_player_moving_right = False

    game_over = False
    show_score_screen = False

    health = 3
    score = 0

    falling_tatlis = []

    # ---------------------------------------------------------
    # WHEEL
    # ---------------------------------------------------------

    next_spin_time = None
    wheel_spinning = False
    waiting_for_player = False

    wheel_angle = 0.0
    wheel_start_angle = 0.0
    wheel_target_angle = 0.0

    spin_start_time = 0
    spin_duration = 2000

    spin_deadline = None
    spin_count = 0

    selected_color_name = ""
    target_sector_index = 0

    player_color = (0, 206, 209)
    player_size = 60

    # ---------------------------------------------------------
    # SOUND VARIABLES
    #
    # IMPORTANT:
    # Sounds are NOT loaded here.
    # They will be loaded after the user presses B.
    # This prevents browser autoplay problems.
    # ---------------------------------------------------------

    scream_sound = None
    pilis_sound = None
    malsef_sound = None
    cough_sound = None
    hit_sound = None

    scream_channel = None
    pilis_channel = None
    malsef_channel = None
    cough_channel = None

    sounds_initialized = False

    # ---------------------------------------------------------
    # IMAGES
    # ---------------------------------------------------------

    room_background = load_image("odda.png", False)

    if room_background is not None:
        room_background = pygame.transform.smoothscale(
            room_background,
            (WIDTH, HEIGHT),
        )

    game_over_background = load_image(
        "oluekaran.jpeg",
        False,
    )

    if game_over_background is not None:
        game_over_background = pygame.transform.smoothscale(
            game_over_background,
            (WIDTH, HEIGHT),
        )

    dark_screen_image = load_image(
        "dur.png",
        True,
    )

    if dark_screen_image is not None:

        dark_screen_image = pygame.transform.smoothscale(
            dark_screen_image,
            (290, 200),
        )

    # ---------------------------------------------------------
    # ROOM PLAYER
    # ---------------------------------------------------------

    room_player_width = 140
    room_player_height = 250

    def load_room_player_image(filename):

        image = load_image(filename, True)

        if image is None:
            return None

        visible_rect = image.get_bounding_rect(min_alpha=10)

        if visible_rect.width <= 0 or visible_rect.height <= 0:
            return pygame.transform.smoothscale(
                image,
                (
                    room_player_width,
                    room_player_height,
                ),
            )

        image = image.subsurface(
            visible_rect
        ).copy()

        return pygame.transform.smoothscale(
            image,
            (
                room_player_width,
                room_player_height,
            ),
        )

    room_player_image = load_room_player_image(
        "oyuncuk.png"
    )

    room_player_left_image = load_room_player_image(
        "oyuncuk_sol.png"
    )

    room_player_right_image = load_room_player_image(
        "oyuncuk_sag.png"
    )

    if room_player_image is not None:
        room_player_rect = room_player_image.get_rect(
            midbottom=(WIDTH // 2, HEIGHT)
        )
    else:
        room_player_rect = pygame.Rect(
            WIDTH // 2 - 70,
            HEIGHT - 250,
            140,
            250,
        )

    # ---------------------------------------------------------
    # FALLING OBJECT
    # ---------------------------------------------------------

    tatlis_image = load_image(
        "tatlis.png",
        True,
    )

    if tatlis_image is not None:

        visible_rect = tatlis_image.get_bounding_rect(
            min_alpha=10
        )

        if visible_rect.width > 0 and visible_rect.height > 0:
            tatlis_image = tatlis_image.subsurface(
                visible_rect
            ).copy()

        tatlis_image = pygame.transform.smoothscale(
            tatlis_image,
            (85, 85),
        )

    # ---------------------------------------------------------
    # COLOR SQUARES
    # ---------------------------------------------------------

    image_files = [
        "kirmizicik.png",
        "turuncucuk.png",
        "saricik.jpg",
        "yesilcik.jpg",
        "pembecik.jpg",
        "morcuk.jpg",
    ]

    square_size = WIDTH // len(image_files)

    player_rect = pygame.Rect(
        WIDTH // 2 - player_size // 2,
        HEIGHT - square_size - player_size,
        player_size,
        player_size,
    )

    square_images = []

    for image_file in image_files:

        image = load_image(
            image_file,
            True,
        )

        if image is not None:

            image = pygame.transform.smoothscale(
                image,
                (
                    square_size,
                    square_size,
                ),
            )

        square_images.append(image)

    square_rects = []

    for i in range(len(image_files)):

        rect = pygame.Rect(
            i * square_size,
            HEIGHT - square_size,
            square_size,
            square_size,
        )

        square_rects.append(rect)

    # ---------------------------------------------------------
    # WHEEL
    # ---------------------------------------------------------

    wheel_image = load_image(
        "cark.png",
        True,
    )

    wheel_size = 180

    if wheel_image is not None:

        wheel_image = pygame.transform.smoothscale(
            wheel_image,
            (
                wheel_size,
                wheel_size,
            ),
        )

        wheel_width, wheel_height = wheel_image.get_size()

        for x in range(wheel_width):

            for y in range(wheel_height):

                pixel = wheel_image.get_at(
                    (x, y)
                )

                r, g, b, a = pixel

                if a == 0:
                    continue

                if (
                    b > 140
                    and b > r + 30
                    and b > g + 30
                ):

                    wheel_image.set_at(
                        (x, y),
                        (255, 0, 255, a),
                    )

        wheel_rect = wheel_image.get_rect(
            center=(
                WIDTH // 2,
                HEIGHT // 2 - 70,
            )
        )

    else:

        wheel_rect = pygame.Rect(
            WIDTH // 2 - 90,
            HEIGHT // 2 - 160,
            180,
            180,
        )

    wheel_sector_names = [
        "KIRMIZI",
        "TURUNCU",
        "SARI",
        "YESIL",
        "PEMBE",
        "MOR",
    ]

    sector_angle = (
        360 / len(wheel_sector_names)
    )

    # ---------------------------------------------------------
    # SOUND INITIALIZATION
    # ---------------------------------------------------------

    def initialize_sounds():

        nonlocal scream_sound
        nonlocal pilis_sound
        nonlocal malsef_sound
        nonlocal cough_sound
        nonlocal hit_sound
        nonlocal sounds_initialized

        if sounds_initialized:
            return

        try:

            if not pygame.mixer.get_init():
                pygame.mixer.init()

        except Exception as e:

            print("MIXER INIT ERROR:", e)

            sounds_initialized = True
            return

        scream_sound = load_sound(
            "ciglik.ogg"
        )

        pilis_sound = load_sound(
            "pilis.ogg"
        )

        malsef_sound = load_sound(
            "malsef.ogg"
        )

        cough_sound = load_sound(
            "oksur.ogg"
        )

        hit_sound = load_sound(
            "uh.ogg"
        )

        sounds_initialized = True

    # ---------------------------------------------------------
    # SPIN INTERVAL
    # ---------------------------------------------------------

    def get_spin_interval():

        if spin_count >= 40:
            return 1

        if spin_count >= 30:
            return 2

        if spin_count >= 20:
            return 3

        if spin_count >= 10:
            return 4

        return 5

    # ---------------------------------------------------------
    # MAIN LOOP
    # ---------------------------------------------------------

    running = True

    while running:

        now = pygame.time.get_ticks()

        # -----------------------------------------------------
        # EVENTS
        # -----------------------------------------------------

        for event in pygame.event.get():

            if event.type == pygame.QUIT:

                running = False

            elif (
                event.type == pygame.KEYDOWN
                and event.key == pygame.K_r
            ):

                try:
                    pygame.mixer.stop()
                except Exception:
                    pass

                return True

            elif (
                game_over
                and event.type == pygame.KEYDOWN
                and event.key == pygame.K_t
            ):

                show_score_screen = True

            elif (
                room_scene
                and not game_over
                and event.type == pygame.KEYDOWN
                and event.key in (
                    pygame.K_LEFT,
                    pygame.K_a,
                )
            ):

                room_player_moving_left = True

            elif (
                room_scene
                and event.type == pygame.KEYUP
                and event.key in (
                    pygame.K_LEFT,
                    pygame.K_a,
                )
            ):

                room_player_moving_left = False

            elif (
                room_scene
                and not game_over
                and event.type == pygame.KEYDOWN
                and event.key in (
                    pygame.K_RIGHT,
                    pygame.K_d,
                )
            ):

                room_player_moving_right = True

            elif (
                room_scene
                and event.type == pygame.KEYUP
                and event.key in (
                    pygame.K_RIGHT,
                    pygame.K_d,
                )
            ):

                room_player_moving_right = False

            # -------------------------------------------------
            # B = START GAME
            # -------------------------------------------------

            elif (
                event.type == pygame.KEYDOWN
                and in_intro
                and event.key == pygame.K_b
            ):

                # THIS IS A USER ACTION.
                # Browser allows audio after this event.

                initialize_sounds()

                in_intro = False

                next_spin_time = now + 5000

            # -------------------------------------------------
            # BACKGROUND COLOR CHANGE
            # -------------------------------------------------

            elif (
                event.type == pygame.USEREVENT + 1
                and not in_intro
            ):

                color_index = (
                    color_index + 1
                ) % len(colors)

            elif (
                event.type == pygame.USEREVENT + 2
                and in_intro
            ):

                intro_color_index = (
                    intro_color_index + 1
                ) % len(intro_colors)

        # -----------------------------------------------------
        # PLAYER MOVEMENT
        # -----------------------------------------------------

        if (
            not in_intro
            and not game_won
            and not black_screen
        ):

            pressed_keys = pygame.key.get_pressed()

            move_amount = 45

            if (
                pressed_keys[pygame.K_a]
                or pressed_keys[pygame.K_LEFT]
            ):

                player_rect.x -= move_amount

            if (
                pressed_keys[pygame.K_d]
                or pressed_keys[pygame.K_RIGHT]
            ):

                player_rect.x += move_amount

            player_rect.x = max(
                0,
                min(
                    WIDTH - player_size,
                    player_rect.x,
                ),
            )

        # -----------------------------------------------------
        # ROOM MOVEMENT
        # -----------------------------------------------------

        if (
            room_scene
            and not game_over
            and room_player_moving_left
        ):

            room_player_rect.x -= 12

            room_player_rect.left = max(
                0,
                room_player_rect.left,
            )

        if (
            room_scene
            and not game_over
            and room_player_moving_right
        ):

            room_player_rect.x += 12

            room_player_rect.right = min(
                WIDTH,
                room_player_rect.right,
            )

        # -----------------------------------------------------
        # FALLING CANDIES
        # -----------------------------------------------------

        if (
            room_scene
            and not game_over
            and room_scene_start_time is not None
            and now >= room_scene_start_time + 5000
            and tatlis_image is not None
        ):

            if not falling_tatlis:

                tatlis_rect = tatlis_image.get_rect(
                    x=random.randint(
                        0,
                        WIDTH
                        - tatlis_image.get_width(),
                    ),
                    bottom=0,
                )

                falling_tatlis.append(
                    tatlis_rect
                )

            tatlis_speed = (
                4 + (score // 5) * 5
            )

            for tatlis_rect in falling_tatlis[:]:

                tatlis_rect.y += tatlis_speed

                if tatlis_rect.colliderect(
                    room_player_rect
                ):

                    if hit_sound is not None:
                        try:
                            hit_sound.play()
                        except Exception:
                            pass

                    health = max(
                        0,
                        health - 1,
                    )

                    falling_tatlis.remove(
                        tatlis_rect
                    )

                    if health == 0:

                        game_over = True

                        room_player_moving_left = False
                        room_player_moving_right = False

                elif tatlis_rect.top >= HEIGHT:

                    score += 1

                    falling_tatlis.remove(
                        tatlis_rect
                    )

        # -----------------------------------------------------
        # START WHEEL
        # -----------------------------------------------------

        if (
            not in_intro
            and not game_won
            and not black_screen
            and not wheel_spinning
            and not waiting_for_player
            and next_spin_time is not None
            and now >= next_spin_time
        ):

            wheel_spinning = True

            next_spin_time = None

            wheel_start_angle = wheel_angle

            final_angle = random.uniform(
                0,
                360,
            )

            spin_rounds = random.randint(
                4,
                7,
            )

            spin_duration = random.randint(
                1000,
                2200,
            )

            wheel_target_angle = (
                wheel_start_angle
                + 360 * spin_rounds
                + final_angle
            )

            spin_start_time = now

        # -----------------------------------------------------
        # WHEEL ANIMATION
        # -----------------------------------------------------

        if (
            wheel_spinning
            and not black_screen
        ):

            progress = min(
                1.0,
                (
                    now - spin_start_time
                ) / spin_duration,
            )

            ease = (
                1
                - (1 - progress) ** 3
            )

            wheel_angle = (
                wheel_start_angle
                + (
                    wheel_target_angle
                    - wheel_start_angle
                ) * ease
            )

            if progress >= 1.0:

                wheel_spinning = False
                waiting_for_player = True

                wheel_angle = (
                    wheel_target_angle
                )

                displayed_top_angle = (
                    -wheel_angle
                ) % 360

                target_sector_index = int(
                    (
                        (
                            displayed_top_angle
                            + sector_angle / 2
                        ) % 360
                    )
                    // sector_angle
                ) % len(
                    wheel_sector_names
                )

                selected_color_name = (
                    wheel_sector_names[
                        target_sector_index
                    ]
                )

                player_color = color_map[
                    selected_color_name
                ]

                spin_count += 1

                player_time = (
                    get_spin_interval()
                )

                spin_deadline = (
                    now
                    + player_time * 1000
                )

        # -----------------------------------------------------
        # CHECK PLAYER POSITION
        # -----------------------------------------------------

        if (
            waiting_for_player
            and not black_screen
            and spin_deadline is not None
            and now >= spin_deadline
        ):

            target_rect = square_rects[
                target_sector_index
            ]

            player_is_on_target = (
                player_rect.right
                > target_rect.left
                and
                player_rect.left
                < target_rect.right
            )

            if player_is_on_target:

                waiting_for_player = False
                spin_deadline = None

                if spin_count >= 50:

                    game_won = True

                else:

                    next_spin_time = now

            else:

                black_screen = True

                black_screen_start_time = now

                waiting_for_player = False
                spin_deadline = None

        # -----------------------------------------------------
        # BLACK SCREEN SOUND SEQUENCE
        # -----------------------------------------------------

        if (
            black_screen
            and black_screen_start_time is not None
        ):

            # Scream

            if not scream_started:

                if scream_sound is not None:

                    try:
                        scream_channel = (
                            scream_sound.play()
                        )
                    except Exception:
                        scream_channel = None

                scream_started = True

            if (
                scream_started
                and not scream_finished
                and (
                    scream_channel is None
                    or not scream_channel.get_busy()
                )
            ):

                scream_finished = True

                if pilis_sound is not None:

                    try:
                        pilis_channel = (
                            pilis_sound.play()
                        )
                    except Exception:
                        pilis_channel = None

                pilis_started = True

            if (
                pilis_started
                and not pilis_finished
                and (
                    pilis_channel is None
                    or not pilis_channel.get_busy()
                )
            ):

                pilis_finished = True

                if malsef_sound is not None:

                    try:
                        malsef_channel = (
                            malsef_sound.play()
                        )
                    except Exception:
                        malsef_channel = None

                malsef_started = True

            if (
                malsef_started
                and not malsef_finished
                and (
                    malsef_channel is None
                    or not malsef_channel.get_busy()
                )
            ):

                malsef_finished = True

                room_scene = True

                room_scene_start_time = now

                if cough_sound is not None:

                    try:
                        cough_channel = (
                            cough_sound.play()
                        )
                    except Exception:
                        cough_channel = None

        # =====================================================
        # DRAW
        # =====================================================

        # -----------------------------------------------------
        # SCORE SCREEN
        # -----------------------------------------------------

        if (
            game_over
            and show_score_screen
        ):

            screen.fill(
                (0, 0, 0)
            )

            color_score_text = (
                intro_font.render(
                    "RenkOyunuSkoru: "
                    + str(spin_count),
                    True,
                    (255, 255, 255),
                )
            )

            secret_score_text = (
                intro_font.render(
                    "GizliOdaOyunu: "
                    + str(score),
                    True,
                    (255, 255, 255),
                )
            )

            screen.blit(
                color_score_text,
                color_score_text.get_rect(
                    center=(
                        WIDTH // 2,
                        HEIGHT // 2 - 35,
                    )
                ),
            )

            screen.blit(
                secret_score_text,
                secret_score_text.get_rect(
                    center=(
                        WIDTH // 2,
                        HEIGHT // 2 + 35,
                    )
                ),
            )

        # -----------------------------------------------------
        # GAME OVER
        # -----------------------------------------------------

        elif game_over:

            if game_over_background is not None:

                screen.blit(
                    game_over_background,
                    (0, 0),
                )

            else:

                screen.fill(
                    (0, 0, 0)
                )

            score_hint = font.render(
                "Skoru gormek icin T'ye basin",
                True,
                (255, 255, 255),
            )

            restart_hint = font.render(
                "Tekrar oynamak icin R'ye basin",
                True,
                (255, 255, 255),
            )

            screen.blit(
                score_hint,
                score_hint.get_rect(
                    center=(
                        WIDTH // 2,
                        HEIGHT - 85,
                    )
                ),
            )

            screen.blit(
                restart_hint,
                restart_hint.get_rect(
                    center=(
                        WIDTH // 2,
                        HEIGHT - 45,
                    )
                ),
            )

        # -----------------------------------------------------
        # INTRO
        # -----------------------------------------------------

        elif in_intro:

            screen.fill(
                intro_colors[
                    intro_color_index
                ]
            )

            intro_title = (
                intro_font.render(
                    "Hareket: A, D veya Sag, Sol",
                    True,
                    (0, 0, 0),
                )
            )

            intro_lines = [

                "Bu asiri masum renk oyununda bir kare olarak",

                "doguyorsunuz. 5 saniyede bir renk degistiriyorsunuz",

                "ve bunu on ve onun katlarinda yapinca saniye degeri",

                "bir azalıyor ve eger istenen renkte istenen zamanda",

                "olamazsaniz... Neyse, onu bosverin...",

            ]

            hint_text = font.render(
                "Baslamak icin B tusuna basin",
                True,
                (0, 0, 0),
            )

            restart_intro_text = (
                font.render(
                    "Tekrar oynamak icin R'ye basin",
                    True,
                    (0, 0, 0),
                )
            )

            screen.blit(
                intro_title,
                intro_title.get_rect(
                    center=(
                        WIDTH // 2,
                        HEIGHT // 2 - 90,
                    )
                ),
            )

            for index, line in enumerate(
                intro_lines
            ):

                line_surface = (
                    font.render(
                        line,
                        True,
                        (255, 255, 255),
                    )
                )

                screen.blit(
                    line_surface,
                    line_surface.get_rect(
                        center=(
                            WIDTH // 2,
                            HEIGHT // 2
                            - 30
                            + index * 30,
                        )
                    ),
                )

            screen.blit(
                hint_text,
                hint_text.get_rect(
                    center=(
                        WIDTH // 2,
                        HEIGHT - 65,
                    )
                ),
            )

            screen.blit(
                restart_intro_text,
                restart_intro_text.get_rect(
                    center=(
                        WIDTH // 2,
                        HEIGHT - 30,
                    )
                ),
            )

        # -----------------------------------------------------
        # SECRET ROOM
        # -----------------------------------------------------

        elif room_scene:

            if room_background is not None:

                screen.blit(
                    room_background,
                    (0, 0),
                )

            else:

                screen.fill(
                    (30, 30, 30)
                )

            if tatlis_image is not None:

                for tatlis_rect in falling_tatlis:

                    screen.blit(
                        tatlis_image,
                        tatlis_rect,
                    )

            if (
                room_player_moving_left
                and room_player_left_image is not None
            ):

                current_room_player = (
                    room_player_left_image
                )

            elif (
                room_player_moving_right
                and room_player_right_image is not None
            ):

                current_room_player = (
                    room_player_right_image
                )

            else:

                current_room_player = (
                    room_player_image
                )

            if current_room_player is not None:

                screen.blit(
                    current_room_player,
                    room_player_rect,
                )

            else:

                pygame.draw.rect(
                    screen,
                    (0, 255, 0),
                    room_player_rect,
                )

            countdown = max(
                0,
                5
                - (
                    now
                    - room_scene_start_time
                ) // 1000,
            )

            countdown_text = (
                countdown_font.render(
                    str(countdown),
                    True,
                    (255, 255, 255),
                )
            )

            screen.blit(
                countdown_text,
                countdown_text.get_rect(
                    center=(
                        WIDTH // 2,
                        55,
                    )
                ),
            )

            score_text = font.render(
                "SKOR: " + str(score),
                True,
                (255, 255, 255),
            )

            health_text = font.render(
                "CAN: " + str(health),
                True,
                (255, 255, 255),
            )

            screen.blit(
                score_text,
                (20, 20),
            )

            screen.blit(
                health_text,
                (
                    WIDTH
                    - health_text.get_width()
                    - 20,
                    20,
                ),
            )

        # -----------------------------------------------------
        # BLACK SCREEN
        # -----------------------------------------------------

        elif black_screen:

            screen.fill(
                (0, 0, 0)
            )

            if dark_screen_image is not None:

                dark_rect = (
                    dark_screen_image.get_rect(
                        center=(
                            WIDTH // 2,
                            HEIGHT // 2,
                        )
                    )
                )

                screen.blit(
                    dark_screen_image,
                    dark_rect,
                )

        # -----------------------------------------------------
        # NORMAL GAME
        # -----------------------------------------------------

        else:

            screen.fill(
                colors[color_index]
            )

            if wheel_image is not None:

                rotated_wheel = (
                    pygame.transform.rotozoom(
                        wheel_image,
                        -wheel_angle,
                        1.0,
                    )
                )

                rotated_rect = (
                    rotated_wheel.get_rect(
                        center=wheel_rect.center
                    )
                )

                screen.blit(
                    rotated_wheel,
                    rotated_rect,
                )

            else:

                pygame.draw.circle(
                    screen,
                    (255, 255, 255),
                    wheel_rect.center,
                    90,
                )

            for image, rect in zip(
                square_images,
                square_rects,
            ):

                if image is not None:

                    screen.blit(
                        image,
                        rect,
                    )

                else:

                    pygame.draw.rect(
                        screen,
                        (100, 100, 100),
                        rect,
                    )

            pygame.draw.rect(
                screen,
                player_color,
                player_rect,
            )

            if selected_color_name:

                result_text = font.render(
                    "RENK: "
                    + selected_color_name,
                    True,
                    (0, 0, 0),
                )

                screen.blit(
                    result_text,
                    result_text.get_rect(
                        center=(
                            WIDTH // 2,
                            HEIGHT
                            - square_size
                            - 40,
                        )
                    ),
                )

            if (
                waiting_for_player
                and spin_deadline is not None
            ):

                seconds_remaining = max(
                    0,
                    (
                        spin_deadline
                        - now
                        + 999
                    ) // 1000,
                )

                grace_text = font.render(
                    "Hedefe varmak icin: "
                    + str(seconds_remaining)
                    + " sn",
                    True,
                    (0, 0, 0),
                )

                screen.blit(
                    grace_text,
                    grace_text.get_rect(
                        center=(
                            WIDTH // 2,
                            HEIGHT
                            - square_size
                            - 70,
                        )
                    ),
                )

            elif (
                not game_won
                and next_spin_time is not None
            ):

                seconds_left = max(
                    0,
                    (
                        next_spin_time
                        - now
                        + 999
                    ) // 1000,
                )

                timer_text = font.render(
                    "Sonraki cark: "
                    + str(seconds_left)
                    + " sn",
                    True,
                    (0, 0, 0),
                )

                screen.blit(
                    timer_text,
                    timer_text.get_rect(
                        center=(
                            WIDTH // 2,
                            HEIGHT
                            - square_size
                            - 70,
                        )
                    ),
                )

            count_text = font.render(
                "Cark sayisi: "
                + str(spin_count),
                True,
                (0, 0, 0),
            )

            screen.blit(
                count_text,
                count_text.get_rect(
                    center=(
                        WIDTH // 2,
                        HEIGHT
                        - square_size
                        - 105,
                    )
                ),
            )

            if game_won:

                win_text = (
                    intro_font.render(
                        "KAZANDIN!",
                        True,
                        (0, 0, 0),
                    )
                )

                screen.blit(
                    win_text,
                    win_text.get_rect(
                        center=(
                            WIDTH // 2,
                            HEIGHT // 2
                            + wheel_size // 2
                            + 40,
                        )
                    ),
                )

        pygame.display.flip()

        clock.tick(60)

        # IMPORTANT FOR PYGBAG
        await asyncio.sleep(0)

    return False


async def main():

    restart = True

    while restart:

        restart = await play_game()

    try:
        pygame.mixer.stop()
    except Exception:
        pass

    pygame.quit()

    sys.exit()


if __name__ == "__main__":

    asyncio.run(main())